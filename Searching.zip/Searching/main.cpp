#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <algorithm>
#include <chrono>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <time.h>
using namespace std;
using namespace std::chrono;
class searcher
{

public:
    int length=0;
    vector <string>vec;
    vector<string>vec2;
    void load_data(int length)
    {
        fstream inputfile;
        inputfile.open("words 2.txt",ios::in);
        if(inputfile.is_open())
        {
            cout<<"it's open"<<endl;
        }
        else
        {
            cout<<"off"<<endl;
        }
        string word;
        for (int i=0; !(inputfile.eof()); i++)
        {
            inputfile>>word;
            vec.push_back(word);
        }

        sort(vec.begin(),vec.end());
        inputfile.close();
    }
    void loadData(int length)
    {
        fstream inputfile;
        inputfile.open("words.txt",ios::in);
        if(inputfile.is_open())
        {
            cout<<"it's open"<<endl;
        }
        else
        {
            cout<<"off"<<endl;
        }
        string word;
        for (int i=0;!(inputfile.eof());i++)
        {
            inputfile>>word;
            vec2.push_back(word);
        }
        sort(vec2.begin(),vec2.end());
        inputfile.close();
    }


    int linearsearch(string key)
    {
        for(int i=0;i<vec2.size();i++)
        {
            if(vec2[i]==key)
                return i;
        }

        return -1;
    }

    int binarysearch(string key,int l,int h)
    {
        while(l<=h)
        {
            int m =(l+h)/2;
            if(vec2[m]==key)
            {
                return m;
            }
            if(vec2[m]>key)
            {
                h=m-1;
            }
            else
            {
                l=m+1;
            }
        }

        return -1;
    }
    int linear_search(string key)
    {
        int numofcomparisonlinear=0;
        for(int i=0;i<vec.size();i++)
        {
            numofcomparisonlinear++;

            if(vec[i]==key)
            {
                return numofcomparisonlinear;

            }
        }
        return numofcomparisonlinear;
    }

    int binary_search(string key,int l,int h)
    {
        int numofcomparisonbinary=0;
        while(l<=h)
        {
            numofcomparisonbinary++;
            int m =(l+h)/2;
            if(vec[m]==key)
            {
                return numofcomparisonbinary;
            }
            if(vec[m]>key)
            {
                h=m-1;
            }
            else
            {
                l=m+1;
            }
        }

        return numofcomparisonbinary;
    }
    void testPerformanceAverage()
    {
        ofstream outfile("Plotting.csv",ios::binary);
        outfile<<" Number of comparisons  binary"<<","<<"Time binary"<<","<<"Number of comparisons linear"<<","<<"Time linear"<<"\n";
        ofstream myfile("PlottingAverageCase.csv",ios::binary);
        myfile<<"SIZE"<<","<<"ave_comp_binary"<<","<<"ave_time_binary"<<","<<"ave_comp_linear"<<","<<"ave_time_linear"<<"\n";
        int sumofcomparisonbinary=0;
        int sumofcomparisonlinear=0;
        vector<string>call; //new vector that has 10 random words
        int size=0,index=0;
        int sumtimelinear=0;
        int sumtimebinary=0;
        vector<int>numbers;
        size=100000;
        srand(time(0)); //for random
        int m=10;
        for(int i=0;i<100;i++)
        {
            index=rand()%size;
            numbers.push_back(index);
            if(i==m)
            {
                size+=100000;
                m+=10;
            }
        }
        int bin,lin;
        double average_comp_lin = 0.0,average_comp_bin = 0.0,average_time_bin = 0.0,average_time_lin = 0.0;
        size=100000;
        int k=0;
         for(int j=0;j<10;j++)
          {
            for(int i=0;i<10;i++)
            {
                call.push_back(vec[numbers[k]]); // put the vec[index] in the new vector called call
                auto startTime = high_resolution_clock::now();
                bin=binary_search(call[i],0,size-1);
                outfile<<bin<<",";
                sumofcomparisonbinary+=bin;
                auto endTime = high_resolution_clock::now();
                auto elapsed = duration_cast<microseconds>(endTime - startTime);
                outfile<<elapsed.count()<<",";
                sumtimebinary+= elapsed.count();
                auto startTime1 = high_resolution_clock::now();
                lin=linear_search(call[i]);
                outfile<<lin<<",";
                sumofcomparisonlinear+=lin;
                auto endTime1 = high_resolution_clock::now();
                auto elapsed1 = duration_cast<microseconds>(endTime1 - startTime1);
                outfile<<elapsed1.count()<<endl;
                sumtimelinear+= elapsed1.count();
                k++;
            }
            myfile<<size<<",";
            size+=100000; // the size of the random that we should increment it
            average_comp_bin=sumofcomparisonbinary/10;
            average_comp_lin=sumofcomparisonlinear/10;
            average_time_bin=sumtimebinary/10;
            average_time_lin=sumtimelinear/10;
            myfile<<average_comp_bin<<",";
            myfile<<average_time_bin<<",";
            myfile<<average_comp_lin<<",";
            myfile<<average_time_lin<<endl;
            cout<<"THE TEST OF PERFORMANCE NUMBER : "<<j+1<<endl;
            cout<<"THE AVERAGE OF NUMBER OF COMPARISON IN LINEAR SEARCH = "<<average_comp_lin<<endl;
            cout<<"THE AVERAGE OF TIME IN LINEAR SEARCH = "<<average_time_lin<<" "<<"MICROSECOND"<<endl;
            cout<<"THE AVERAGE OF NUMBER OF COMPARISON IN BINARY SEARCH = "<<average_comp_bin<<endl;
            cout<<"THE AVERAGE OF TIME IN BINARY SEARCH = "<<average_time_bin<<" "<<"MICROSECOND"<<endl;
            cout<<"**"<<endl;
            call.clear();
        sumofcomparisonbinary=0;
        }
        sumofcomparisonlinear=0;
        sumtimebinary=0;
        sumtimelinear=0;
        outfile.close();
        myfile.close();
    }
    void testPerformanceWorst()
    {
        ofstream file1("Plotting2.csv",ios::binary);
        file1<<"Number of comparison binary"<<","<<"Time binary"<<","<<"Number of comparison linear"<<","<<"Time linear"<<"\n";
        ofstream file("PlottingWorstCase.csv",ios::binary);
        file<<"SIZE"<<","<<"ave_comp_binary"<<","<<"ave_time_binary"<<","<<"ave_comp_linear"<<","<<"ave_time_linear"<<"\n";
        int sumofcomparisonbinary=0;
        int sumofcomparisonlinear=0;
        int size=0,index=0;
        int sumtimelinear=0;
        int sumtimebinary=0;
        size=100000;
        int bin,lin;
        int average_comp_lin = 0,average_comp_bin = 0,average_time_bin = 0,average_time_lin = 0;
        for(int j=0;j<10;j++)//for making test performance 10 times
        {
            for(int i=0;i<10;i++)
            {
                auto startTime = high_resolution_clock::now();
                bin=binary_search(",",0,size-1);
                file1<<bin<<",";
                sumofcomparisonbinary+=bin;
                auto endTime = high_resolution_clock::now();
                auto elapsed = duration_cast<microseconds>(endTime - startTime);
                file1<<elapsed.count()<<",";
                sumtimebinary+= elapsed.count();
                auto startTime1 = high_resolution_clock::now();
                lin=linear_search(",");
                file1<<lin<<",";
                sumofcomparisonlinear+=lin;
                auto endTime1 = high_resolution_clock::now();
                auto elapsed1 = duration_cast<microseconds>(endTime1 - startTime1);
                file1<<elapsed1.count()<<endl;
                sumtimelinear+= elapsed1.count();

            }
            file<<size<<",";
            size+=100000; // the size of the random that we should increment it
            average_comp_bin=sumofcomparisonbinary/10;
            average_comp_lin=sumofcomparisonlinear/10;
            average_time_bin=sumtimebinary/10;
            average_time_lin=sumtimelinear/10;
            file<<average_comp_bin<<",";
            file<<average_time_bin<<",";
            file<<average_comp_lin<<",";
            file<<average_time_lin<<endl;
            cout<<"THE TEST OF PERFORMANCE NUMBER : "<<j+1<<endl;
            cout<<"THE AVERAGE OF NUMBER OF COMPARISON IN LINEAR SEARCH = "<<average_comp_lin<<endl;
            cout<<"THE AVERAGE OF TIME IN LINEAR SEARCH = "<<average_time_lin<<" "<<"MICROSECOND"<<endl;
            cout<<"THE AVERAGE OF NUMBER OF COMPARISON IN BINARY SEARCH = "<<average_comp_bin<<endl;
            cout<<"THE AVERAGE OF TIME IN BINARY SEARCH = "<<average_time_bin<<" "<<"MICROSECOND"<<endl;
            cout<<"**"<<endl;
        sumofcomparisonbinary=0;
        }
        sumofcomparisonlinear=0;
        sumtimebinary=0;
        sumtimelinear=0;
        file1.close();
        file.close();
    }
};
int main()
{
    searcher a;
    a.load_data(1000000);
    a.loadData(10000);
    char choice;
    do{

        cout<<"Welcome to FCI Searching"<<endl;
        cout<<"---------------------------------------- "<<endl;
        cout<<"1- linear search\n";
        cout<<"2- Binary search\n";
        cout<<"3- test performance average\n";
        cout<<"4- test performance worst\n";
        cout<<"5- EXIT\n";
        cin>>choice;
        switch(choice)
        {
            case '1':
            {
                string key;
                cout<<"ENTER YOUR WORD YOU WANT TO SEARCH"<<endl;
                cin>>key;
                cout<<"THE POSITION OF " <<key<<" THAT YOU WANT IS :  "<<a.linearsearch(key)<<endl;
                break;
            }
            case '2':
            {
                string key;
                cout<<"ENTER YOUR WORD YOU WANT TO SEARCH"<<endl;
                cin>>key;
                cout<<"THE POSITION OF " <<key<<"THAT YOU WANT IS : "<< a.binarysearch(key,0,10000)<<endl;
                break;
            }
            case '3':
            {
                a.testPerformanceAverage();

                break;
            }
            case '4':
            {
                a.testPerformanceWorst();

                break;
            }
            case '5':
            {
                cout<<"GOODBYE"<<endl;
                break;
            }
            default :
            {
                cout<<"you have entered invalid number , please try again\n";
            }
        }
    }while(choice!='5');

    return 0;
}
